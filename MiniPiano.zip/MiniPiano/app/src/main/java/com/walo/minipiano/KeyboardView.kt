package com.walo.minipiano

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.SparseIntArray
import android.view.MotionEvent
import android.view.View

/** 25 teclas (2 octavas + Do). Multitouch real: cada dedo (pointerId) controla su propia nota. */
class KeyboardView(ctx: Context) : View(ctx) {
    private val n = 25
    private val black = BooleanArray(n) { (it % 12) in intArrayOf(1, 3, 6, 8, 10) }
    private val rect = Array(n) { RectF() }
    private val whiteIdx = IntArray(15)
    private val ptrKey = SparseIntArray()
    private val ptrMidi = SparseIntArray()
    private val ptrTok = SparseIntArray()
    private val down = BooleanArray(n)
    private var kw = 1f
    private var hl = IntArray(0)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF555555.toInt(); textAlign = Paint.Align.CENTER }

    private fun base() = 48 + 12 * Synth.octaveShift

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        kw = w / 15f
        var wi = 0
        for (i in 0 until n) if (!black[i]) {
            rect[i].set(wi * kw + 1f, 0f, (wi + 1) * kw - 1f, h.toFloat()); whiteIdx[wi++] = i
        }
        val bw = kw * 0.62f
        for (i in 0 until n) if (black[i]) {
            val cx = rect[i - 1].right + 1f
            rect[i].set(cx - bw / 2, 0f, cx + bw / 2, h * 0.62f)
        }
        txt.textSize = kw * 0.32f
    }

    private fun hit(x: Float, y: Float): Int {
        for (i in 0 until n) if (black[i] && rect[i].contains(x, y)) return i
        return whiteIdx[(x / kw).toInt().coerceIn(0, 14)]
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { requestUnbufferedDispatch(e); press(e, 0) }
            MotionEvent.ACTION_POINTER_DOWN -> press(e, e.actionIndex)
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) slide(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP -> lift(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }

    private fun press(e: MotionEvent, i: Int) {
        val id = e.getPointerId(i)
        val k = hit(e.getX(i), e.getY(i)); val midi = base() + k
        ptrKey.put(id, k); ptrMidi.put(id, midi); ptrTok.put(id, Synth.noteOn(midi))
        refresh()
    }

    private fun slide(id: Int, x: Float, y: Float) {
        val old = ptrKey.get(id, -1)
        if (old < 0) return
        val k = hit(x, y)
        if (k == old) return
        Synth.noteOff(ptrTok.get(id))
        val midi = base() + k
        ptrKey.put(id, k); ptrMidi.put(id, midi); ptrTok.put(id, Synth.noteOn(midi))
        refresh()
    }

    private fun lift(id: Int) {
        val tok = ptrTok.get(id, -1)
        if (tok >= 0) Synth.noteOff(tok)
        ptrKey.delete(id); ptrMidi.delete(id); ptrTok.delete(id)
        refresh()
    }

    fun releaseAll() {
        for (j in 0 until ptrTok.size()) Synth.noteOff(ptrTok.valueAt(j))
        ptrKey.clear(); ptrMidi.clear(); ptrTok.clear(); refresh()
    }

    override fun onDetachedFromWindow() { releaseAll(); super.onDetachedFromWindow() }

    /** Resalta (naranja) las notas MIDI indicadas, p. ej. las de un acorde. */
    fun setHighlight(m: IntArray) { hl = m; invalidate() }

    private fun isHl(i: Int): Boolean {
        val mm = base() + i
        for (x in hl) if (x == mm) return true
        return false
    }

    fun refresh() {
        java.util.Arrays.fill(down, false)
        for (j in 0 until ptrMidi.size()) { val i = ptrMidi.valueAt(j) - base(); if (i in 0 until n) down[i] = true }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF0E0F12.toInt())
        for (i in 0 until n) if (!black[i]) {
            p.color = if (down[i]) 0xFF9CC4FF.toInt() else if (isHl(i)) 0xFFFFD08A.toInt() else 0xFFF4F4F4.toInt()
            c.drawRoundRect(rect[i], 6f, 6f, p)
            if (i % 12 == 0) c.drawText("C${(base() + i) / 12 - 1}", rect[i].centerX(), rect[i].bottom - kw * 0.2f, txt)
        }
        for (i in 0 until n) if (black[i]) {
            p.color = if (down[i]) 0xFF3D7BFF.toInt() else if (isHl(i)) 0xFFD98A1F.toInt() else 0xFF1A1A1A.toInt()
            c.drawRoundRect(rect[i], 5f, 5f, p)
        }
    }
}
