package com.walo.minipiano

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Teclado flotante (TYPE_APPLICATION_OVERLAY). No toma foco ni Audio Focus. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var panel: PianoPanel? = null
    private var acquired = false
    private var mode = 1 // 0 pequeña (30%), 1 media (50%), 2 completa

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startFg()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        Synth.acquire(this); acquired = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START }

        val p = PianoPanel(this)
        p.setBackgroundColor(0xF00E0F12.toInt())
        val handle = TextView(this).apply {
            text = "≡  arrastrar"; setTextColor(0xFFAAAAAA.toInt()); gravity = Gravity.CENTER
        }
        p.topBar.addView(handle, LinearLayout.LayoutParams(0, -1, 1f))
        var ly = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> ly = e.rawY
                MotionEvent.ACTION_MOVE -> {
                    if (mode != 2) {
                        val maxY = resources.displayMetrics.heightPixels - lp.height
                        lp.y = (lp.y - (e.rawY - ly)).toInt().coerceIn(0, maxY.coerceAtLeast(0))
                        wm.updateViewLayout(p, lp)
                    }
                    ly = e.rawY
                }
            }
            true
        }
        p.addTopButton("↕ Tamaño") { mode = (mode + 1) % 3; applyMode() }
        p.addTopButton("✕") { stopSelf() }
        panel = p
        applyMode(first = true)
    }

    private fun applyMode(first: Boolean = false) {
        val p = panel ?: return
        val h = resources.displayMetrics.heightPixels
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.x = 0
        when (mode) {
            0 -> lp.height = (h * 0.30f).toInt()
            1 -> lp.height = (h * 0.50f).toInt()
            else -> { lp.height = WindowManager.LayoutParams.MATCH_PARENT; lp.y = 0 }
        }
        if (first) wm.addView(p, lp) else wm.updateViewLayout(p, lp)
    }

    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); applyMode() }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") stopSelf()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kb", "Teclado flotante", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "kb").setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Mini Piano flotante").setContentText("Tocá para cerrar").setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        if (acquired) { Synth.release(); acquired = false }
        super.onDestroy()
    }
}
