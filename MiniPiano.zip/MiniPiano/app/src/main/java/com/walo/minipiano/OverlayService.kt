package com.walo.minipiano

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Teclado flotante (TYPE_APPLICATION_OVERLAY). No toma foco ni Audio Focus. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var blp: WindowManager.LayoutParams
    private var panel: PianoPanel? = null
    private var bubble: TextView? = null
    private var acquired = false
    private var mode = 1 // 0 pequeña (30%), 1 media (50%), 2 completa
    private var minimized = false

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT
    )

    override fun onCreate() {
        super.onCreate()
        startFg()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        Synth.acquire(this); acquired = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        lp = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.BOTTOM or Gravity.START }

        val p = PianoPanel(this)
        p.setBackgroundColor(0xF00E0F12.toInt())
        val handle = TextView(this).apply {
            text = "≡ mover"; setTextColor(0xFFAAAAAA.toInt()); gravity = Gravity.CENTER
        }
        p.topBar.addView(handle, LinearLayout.LayoutParams(0, -1, 1f))
        var ly = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> ly = e.rawY
                MotionEvent.ACTION_MOVE -> {
                    if (mode != 2) {
                        val maxY = resources.displayMetrics.heightPixels - lp.height
                        lp.y = (lp.y - (e.rawY - ly)).toInt().coerceIn(0, maxY.coerceAtLeast(0))
                        wm.updateViewLayout(p, lp)
                    }
                    ly = e.rawY
                }
            }
            true
        }
        p.addTopButton("↕") { mode = (mode + 1) % 3; applyMode() }
        p.addTopButton("—") { setMinimized(true) }
        p.addTopButton("⌂ App") { openApp() }
        p.addTopButton("✕") { stopSelf() }
        panel = p
        buildBubble()
        applyMode(first = true)
    }

    /** Burbuja circular arrastrable; un toque restaura el teclado. */
    private fun buildBubble() {
        val size = dp(56)
        val b = TextView(this).apply {
            text = "🎹"; textSize = 24f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE63D7BFF.toInt()) }
        }
        blp = overlayParams(size, size).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(200) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = blp.x; oy = blp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) {
                        val dm = resources.displayMetrics
                        blp.x = (ox + dx).toInt().coerceIn(0, dm.widthPixels - size)
                        blp.y = (oy + dy).toInt().coerceIn(0, dm.heightPixels - size)
                        wm.updateViewLayout(b, blp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) setMinimized(false)
            }
            true
        }
        bubble = b
    }

    private fun setMinimized(on: Boolean) {
        val p = panel ?: return
        val b = bubble ?: return
        if (on == minimized) return
        minimized = on
        if (on) {
            try { wm.removeView(p) } catch (_: Exception) {}
            p.kb.releaseAll()
            wm.addView(b, blp)
        } else {
            try { wm.removeView(b) } catch (_: Exception) {}
            wm.addView(p, lp)
            p.sync()
        }
    }

    private fun openApp() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
        stopSelf()
    }

    private fun applyMode(first: Boolean = false) {
        val p = panel ?: return
        val h = resources.displayMetrics.heightPixels
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.x = 0
        p.setCompact(mode == 0)
        when (mode) {
            0 -> lp.height = (h * 0.30f).toInt()
            1 -> lp.height = (h * 0.50f).toInt()
            else -> { lp.height = WindowManager.LayoutParams.MATCH_PARENT; lp.y = 0 }
        }
        if (first) wm.addView(p, lp) else if (!minimized) wm.updateViewLayout(p, lp)
    }

    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); applyMode() }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") stopSelf()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kb", "Teclado flotante", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "kb").setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Mini Piano flotante").setContentText("Tocá para cerrar").setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        if (::wm.isInitialized) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        }
        panel = null; bubble = null
        if (acquired) { Synth.release(); acquired = false }
        super.onDestroy()
    }
}
