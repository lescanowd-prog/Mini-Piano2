package com.walo.minipiano

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** UI completa (instrumentos, octava, volumen, teclado). La usan la Activity y la ventana flotante. */
class PianoPanel(ctx: Context) : FrameLayout(ctx) {
    val topBar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val kb = KeyboardView(ctx)
    var onExitFullscreen: (() -> Unit)? = null
    private val controls = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val instBtns = ArrayList<Button>()
    private val octLabel = TextView(ctx)
    private val seek = SeekBar(ctx)
    private val exitBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun btn(t: String): Button = Button(context).apply {
        text = t; isAllCaps = false; textSize = 13f; setTextColor(0xFFFFFFFF.toInt())
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(6), dp(4), dp(6), dp(4)); stateListAnimator = null
        background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(0xFF2B2F36.toInt()) }
    }

    private fun paint(b: Button, on: Boolean) {
        (b.background as GradientDrawable).setColor(if (on) 0xFF3D7BFF.toInt() else 0xFF2B2F36.toInt())
    }

    fun addTopButton(t: String, f: () -> Unit): Button = btn(t).also {
        it.setOnClickListener { f() }
        topBar.addView(it, lp(-2, -1).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
    }

    init {
        val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        body.addView(topBar, lp(-1, dp(40)))

        val r1 = LinearLayout(ctx)
        Synth.NAMES.forEachIndexed { i, name ->
            val b = btn(name)
            b.setOnClickListener { Synth.instrument = i; syncInst() }
            instBtns.add(b)
            r1.addView(b, lp(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        controls.addView(r1, lp(-1, dp(44)))

        val r2 = LinearLayout(ctx)
        val om = btn("OCT −").also { it.setOnClickListener { shiftOct(-1) } }
        val op = btn("OCT +").also { it.setOnClickListener { shiftOct(1) } }
        octLabel.apply { setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER; textSize = 12f }
        val og = LinearLayout(ctx)
        og.addView(om, lp(0, -1, 1f)); og.addView(octLabel, lp(0, -1, 1.2f)); og.addView(op, lp(0, -1, 1f))

        val vm = btn("−").also { it.setOnClickListener { seek.progress = (seek.progress - 5).coerceAtLeast(0) } }
        val vp = btn("+").also { it.setOnClickListener { seek.progress = (seek.progress + 5).coerceAtMost(100) } }
        seek.max = 100; seek.progress = (Synth.volume * 100).toInt()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { Synth.volume = p / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val vg = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        vg.addView(vm, lp(dp(34), -1)); vg.addView(seek, lp(0, -2, 1f)); vg.addView(vp, lp(dp(34), -1))

        r2.addView(og, lp(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(6), dp(2)) })
        r2.addView(vg, lp(0, -1, 1f).apply { setMargins(dp(6), dp(2), dp(2), dp(2)) })
        controls.addView(r2, lp(-1, dp(44)))

        body.addView(controls, lp(-1, -2))
        body.addView(kb, lp(-1, 0, 1f))
        addView(body, LayoutParams(-1, -1))

        exitBtn = btn("✕").apply { visibility = GONE; setOnClickListener { onExitFullscreen?.invoke() } }
        addView(exitBtn, LayoutParams(dp(44), dp(36), Gravity.TOP or Gravity.END).apply {
            setMargins(dp(6), dp(6), dp(6), dp(6))
        })
        sync()
    }

    private fun shiftOct(d: Int) {
        Synth.octaveShift = (Synth.octaveShift + d).coerceIn(-2, 3)
        syncOct(); kb.refresh()
    }

    private fun syncInst() { instBtns.forEachIndexed { i, b -> paint(b, i == Synth.instrument) } }
    private fun syncOct() {
        val o = (48 + 12 * Synth.octaveShift) / 12 - 1
        octLabel.text = "C$o–C${o + 2}"
    }

    /** Re-sincroniza la UI con el estado global (por si otra ventana lo cambió). */
    fun sync() { syncInst(); syncOct(); seek.progress = (Synth.volume * 100).toInt(); kb.refresh() }

    fun setFullscreen(on: Boolean) {
        val v = if (on) GONE else VISIBLE
        controls.visibility = v; topBar.visibility = v
        exitBtn.visibility = if (on) VISIBLE else GONE
    }
}
