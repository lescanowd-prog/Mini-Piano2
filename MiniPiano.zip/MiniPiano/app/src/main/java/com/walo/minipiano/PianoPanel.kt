package com.walo.minipiano

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** UI completa (instrumentos, octava, volumen, reverb, sustain, acordes, teclado). La usan la Activity y la ventana flotante. */
class PianoPanel(ctx: Context) : FrameLayout(ctx) {
    val topBar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    val kb = KeyboardView(ctx)
    var onExitFullscreen: (() -> Unit)? = null
    private val controls = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val picker = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; visibility = GONE }
    private val instBtns = ArrayList<Button>()
    private val rootBtns = ArrayList<Button>()
    private val qualBtns = ArrayList<Button>()
    private val octLabel = TextView(ctx)
    private val chordInfo = TextView(ctx)
    private val seek = SeekBar(ctx)
    private val seekRev = SeekBar(ctx)
    private val seekSus = SeekBar(ctx)
    private val chordBtn: Button
    private val exitBtn: Button
    private var compact = false
    private var full = false
    private var chordRoot = 0
    private var chordQ = 0
    private var chordShow = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun marg(l: LinearLayout.LayoutParams, m: Int): LinearLayout.LayoutParams {
        l.setMargins(dp(m), dp(m), dp(m), dp(m)); return l
    }

    private fun btn(t: String): Button = Button(context).apply {
        text = t; isAllCaps = false; textSize = 13f; setTextColor(0xFFFFFFFF.toInt())
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(4), dp(4), dp(4), dp(4)); stateListAnimator = null
        background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(0xFF2B2F36.toInt()) }
    }

    private fun paint(b: Button, on: Boolean) {
        (b.background as GradientDrawable).setColor(if (on) 0xFF3D7BFF.toInt() else 0xFF2B2F36.toInt())
    }

    fun addTopButton(t: String, f: () -> Unit): Button = btn(t).also {
        it.setOnClickListener { f() }
        topBar.addView(it, lp(-2, -1).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
    }

    private fun labeled(label: String, sb: SeekBar, progress: Int, onChange: (Float) -> Unit): LinearLayout {
        sb.max = 100; sb.progress = progress
        sb.setPadding(dp(8), 0, dp(8), 0)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { onChange(p / 100f) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val tv = TextView(context).apply { text = label; textSize = 11f; setTextColor(0xFFCCCCCC.toInt()) }
        return LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(tv, lp(-2, -2))
            addView(sb, lp(0, -2, 1f))
        }
    }

    /** Botón grande para tocar el acorde elegido (mantener apretado = suena). */
    private inner class Pad(c: Context) : TextView(c) {
        private val ids = ArrayList<Int>()
        init {
            text = "▶ TOCAR ACORDE"; textSize = 15f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xFF2E7D32.toInt()) }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    requestUnbufferedDispatch(e)
                    chordShow = true; syncChord()
                    for (m in chordMidis()) ids.add(Synth.noteOn(m))
                    (background as GradientDrawable).setColor(0xFF66BB6A.toInt())
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    for (id in ids) Synth.noteOff(id)
                    ids.clear()
                    (background as GradientDrawable).setColor(0xFF2E7D32.toInt())
                }
            }
            return true
        }
    }

    init {
        val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        body.addView(topBar, lp(-1, dp(40)))

        // fila 1: instrumentos
        val r1 = LinearLayout(ctx)
        Synth.NAMES.forEachIndexed { i, name ->
            val b = btn(name)
            b.setOnClickListener { Synth.instrument = i; syncInst() }
            instBtns.add(b)
            r1.addView(b, marg(lp(0, -1, 1f), 2))
        }
        controls.addView(r1, lp(-1, dp(44)))

        // fila 2: octava + volumen
        val r2 = LinearLayout(ctx)
        val om = btn("OCT −").also { it.setOnClickListener { shiftOct(-1) } }
        val op = btn("OCT +").also { it.setOnClickListener { shiftOct(1) } }
        octLabel.apply { setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER; textSize = 12f }
        val og = LinearLayout(ctx)
        og.addView(om, lp(0, -1, 1f)); og.addView(octLabel, lp(0, -1, 1.2f)); og.addView(op, lp(0, -1, 1f))

        val vm = btn("−").also { it.setOnClickListener { seek.progress = (seek.progress - 5).coerceAtLeast(0) } }
        val vp = btn("+").also { it.setOnClickListener { seek.progress = (seek.progress + 5).coerceAtMost(100) } }
        seek.max = 100; seek.progress = (Synth.volume * 100).toInt()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { Synth.volume = p / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val vg = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        vg.addView(vm, lp(dp(34), -1)); vg.addView(seek, lp(0, -2, 1f)); vg.addView(vp, lp(dp(34), -1))

        r2.addView(og, marg(lp(0, -1, 1f), 2).also { it.rightMargin = dp(6) })
        r2.addView(vg, marg(lp(0, -1, 1f), 2).also { it.leftMargin = dp(6) })
        controls.addView(r2, lp(-1, dp(44)))

        // fila 3: acordes + reverb + sustain
        val r3 = LinearLayout(ctx)
        chordBtn = btn("♪ Acordes").also { it.setOnClickListener { openPicker(picker.visibility != VISIBLE) } }
        r3.addView(chordBtn, marg(lp(0, -1, 1.1f), 2))
        r3.addView(
            labeled("Rev", seekRev, (Synth.reverb * 100).toInt()) { Synth.reverb = it },
            marg(lp(0, -1, 1f), 2)
        )
        r3.addView(
            labeled("Sus", seekSus, (Synth.sustain * 100).toInt()) { Synth.sustain = it },
            marg(lp(0, -1, 1f), 2)
        )
        controls.addView(r3, lp(-1, dp(44)))
        body.addView(controls, lp(-1, -2))

        // selector de acordes
        val rootRow = LinearLayout(ctx)
        for (i in 0 until 12) {
            val b = btn(Chords.ROOTS[i]); b.textSize = 12f
            b.setOnClickListener { chordRoot = i; chordShow = true; syncChord() }
            rootBtns.add(b)
            rootRow.addView(b, marg(lp(0, -1, 1f), 1))
        }
        picker.addView(rootRow, lp(-1, dp(40)))
        picker.addView(chordInfo.apply { textSize = 13f; setTextColor(0xFFFFD08A.toInt()); setPadding(dp(4), dp(2), dp(4), dp(2)) }, lp(-1, -2))
        val grid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        var row: LinearLayout? = null
        for (i in Chords.QUALITIES.indices) {
            if (i % 5 == 0) { row = LinearLayout(ctx); grid.addView(row, lp(-1, dp(38))) }
            val b = btn(Chords.QUALITIES[i].label); b.textSize = 11f
            b.setOnClickListener { chordQ = i; chordShow = true; syncChord() }
            qualBtns.add(b)
            row!!.addView(b, marg(lp(0, -1, 1f), 1))
        }
        val sv = ScrollView(ctx)
        sv.addView(grid, FrameLayout.LayoutParams(-1, -2))
        picker.addView(sv, lp(-1, 0, 1f))
        val padRow = LinearLayout(ctx)
        padRow.addView(Pad(ctx), marg(lp(0, -1, 3f), 2))
        padRow.addView(btn("Quitar").also { it.setOnClickListener { chordShow = false; syncChord() } }, marg(lp(0, -1, 1f), 2))
        padRow.addView(btn("Cerrar").also { it.setOnClickListener { openPicker(false) } }, marg(lp(0, -1, 1f), 2))
        picker.addView(padRow, lp(-1, dp(52)))
        body.addView(picker, lp(-1, 0, 1f))

        body.addView(kb, lp(-1, 0, 1f))
        addView(body, LayoutParams(-1, -1))

        exitBtn = btn("✕").apply { visibility = GONE; setOnClickListener { onExitFullscreen?.invoke() } }
        addView(exitBtn, LayoutParams(dp(44), dp(36), Gravity.TOP or Gravity.END).apply {
            setMargins(dp(6), dp(6), dp(6), dp(6))
        })
        sync()
    }

    // ---------------------------------------------------------------- acordes
    private fun root() = 48 + 12 * Synth.octaveShift + chordRoot

    /** Notas que suenan con el pad: raíz grave (si entra en rango) + el acorde. */
    private fun chordMidis(): IntArray {
        val r = root(); val iv = Chords.QUALITIES[chordQ].iv
        val low = r - 12 >= 28
        val out = IntArray(iv.size + (if (low) 1 else 0))
        var k = 0
        if (low) out[k++] = r - 12
        for (x in iv) out[k++] = r + x
        return out
    }

    private fun syncChord() {
        rootBtns.forEachIndexed { i, b -> paint(b, chordShow && i == chordRoot) }
        qualBtns.forEachIndexed { i, b -> paint(b, chordShow && i == chordQ) }
        if (chordShow) {
            val name = Chords.name(chordRoot, chordQ)
            chordInfo.text = "$name   ( ${Chords.noteNames(chordRoot, chordQ)} )"
            chordBtn.text = "♪ $name"
            val r = root(); val iv = Chords.QUALITIES[chordQ].iv
            kb.setHighlight(IntArray(iv.size) { r + iv[it] })
        } else {
            chordInfo.text = "Elegí raíz y tipo de acorde"
            chordBtn.text = "♪ Acordes"
            kb.setHighlight(IntArray(0))
        }
    }

    private fun openPicker(on: Boolean) {
        if (on) kb.releaseAll()
        picker.visibility = if (on) VISIBLE else GONE
        kb.visibility = if (on) GONE else VISIBLE
    }

    // ---------------------------------------------------------------- resto de la UI
    private fun shiftOct(d: Int) {
        Synth.octaveShift = (Synth.octaveShift + d).coerceIn(-2, 3)
        syncOct(); kb.refresh(); syncChord()
    }

    private fun syncInst() { instBtns.forEachIndexed { i, b -> paint(b, i == Synth.instrument) } }
    private fun syncOct() {
        val o = (48 + 12 * Synth.octaveShift) / 12 - 1
        octLabel.text = "C$o–C${o + 2}"
    }

    /** Re-sincroniza la UI con el estado global (por si otra ventana lo cambió). */
    fun sync() {
        syncInst(); syncOct()
        seek.progress = (Synth.volume * 100).toInt()
        seekRev.progress = (Synth.reverb * 100).toInt()
        seekSus.progress = (Synth.sustain * 100).toInt()
        syncChord(); kb.refresh()
    }

    private fun applyVis() {
        controls.visibility = if (compact || full) GONE else VISIBLE
        topBar.visibility = if (full) GONE else VISIBLE
        exitBtn.visibility = if (full) VISIBLE else GONE
        if (compact || full) openPicker(false)
    }

    fun setFullscreen(on: Boolean) { full = on; applyVis() }

    /** Modo compacto (ventana flotante chica): solo barra superior + teclado. */
    fun setCompact(on: Boolean) { compact = on; applyVis() }
}
