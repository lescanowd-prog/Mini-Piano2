package com.walo.minipiano

import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var panel: PianoPanel
    private var full = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        volumeControlStream = AudioManager.STREAM_MUSIC
        panel = PianoPanel(this)
        panel.setBackgroundColor(0xFF0E0F12.toInt())
        panel.addTopButton("⛶ Pantalla completa") { setFull(true) }
        panel.addTopButton("▭ Flotante") { startFloating() }
        panel.onExitFullscreen = { setFull(false) }
        setContentView(panel)
    }

    override fun onStart() { super.onStart(); Synth.acquire(this); panel.sync() }
    override fun onStop() { Synth.release(); super.onStop() }

    private fun startFloating() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activá \"Mostrar sobre otras apps\" para Mini Piano y volvé a tocar Flotante", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    private fun setFull(on: Boolean) {
        full = on
        panel.setFullscreen(on)
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(!on)
            window.insetsController?.let {
                if (on) {
                    it.hide(WindowInsets.Type.systemBars())
                    it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else it.show(WindowInsets.Type.systemBars())
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (on)
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            else 0
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (full) setFull(false) else super.onBackPressed() }
}
