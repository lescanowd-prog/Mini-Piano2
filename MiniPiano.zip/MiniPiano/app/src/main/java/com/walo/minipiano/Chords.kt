package com.walo.minipiano

/** Acordes disponibles: raíz C..B + 30 calidades (segundas, terceras, cuartas, disminuidos, séptimas, novenas...). */
object Chords {
    val ROOTS = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    class Q(val label: String, val suffix: String, val iv: IntArray)

    val QUALITIES = arrayOf(
        Q("maj", "", intArrayOf(0, 4, 7)),
        Q("m", "m", intArrayOf(0, 3, 7)),
        Q("dim", "dim", intArrayOf(0, 3, 6)),
        Q("aug", "aug", intArrayOf(0, 4, 8)),
        Q("sus2", "sus2", intArrayOf(0, 2, 7)),
        Q("sus4", "sus4", intArrayOf(0, 5, 7)),
        Q("5", "5", intArrayOf(0, 7, 12)),
        Q("6", "6", intArrayOf(0, 4, 7, 9)),
        Q("m6", "m6", intArrayOf(0, 3, 7, 9)),
        Q("6/9", "6/9", intArrayOf(0, 4, 7, 9, 14)),
        Q("7", "7", intArrayOf(0, 4, 7, 10)),
        Q("maj7", "maj7", intArrayOf(0, 4, 7, 11)),
        Q("m7", "m7", intArrayOf(0, 3, 7, 10)),
        Q("m(maj7)", "m(maj7)", intArrayOf(0, 3, 7, 11)),
        Q("m7b5", "m7b5", intArrayOf(0, 3, 6, 10)),
        Q("dim7", "dim7", intArrayOf(0, 3, 6, 9)),
        Q("7sus4", "7sus4", intArrayOf(0, 5, 7, 10)),
        Q("7b5", "7b5", intArrayOf(0, 4, 6, 10)),
        Q("7#5", "7#5", intArrayOf(0, 4, 8, 10)),
        Q("7b9", "7b9", intArrayOf(0, 4, 7, 10, 13)),
        Q("7#9", "7#9", intArrayOf(0, 4, 7, 10, 15)),
        Q("add9", "add9", intArrayOf(0, 4, 7, 14)),
        Q("m(add9)", "m(add9)", intArrayOf(0, 3, 7, 14)),
        Q("add4", "add4", intArrayOf(0, 4, 5, 7)),
        Q("9", "9", intArrayOf(0, 4, 7, 10, 14)),
        Q("maj9", "maj9", intArrayOf(0, 4, 7, 11, 14)),
        Q("m9", "m9", intArrayOf(0, 3, 7, 10, 14)),
        Q("11", "11", intArrayOf(0, 4, 7, 10, 14, 17)),
        Q("m11", "m11", intArrayOf(0, 3, 7, 10, 14, 17)),
        Q("13", "13", intArrayOf(0, 4, 7, 10, 14, 21))
    )

    fun name(root: Int, q: Int) = ROOTS[root] + QUALITIES[q].suffix

    /** Notas del acorde como nombres (sin octava). */
    fun noteNames(root: Int, q: Int): String =
        QUALITIES[q].iv.joinToString(" ") { ROOTS[(root + it) % 12] }
}
