package com.walo.minipiano

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Process
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Motor de audio: 16 voces sobre AudioTrack de baja latencia (estéreo, float), sin Audio Focus.
 * Cada instrumento usa samples (assets/samples) con interpolación cúbica y loop en los sostenidos;
 * si los samples de un instrumento no cargan, usa la síntesis de respaldo.
 * Incluye reverb (Freeverb) ajustable y release/sustain automático ajustable.
 */
object Synth {
    const val PIANO = 0
    const val BRASS = 1
    const val BASS = 2
    const val ORGAN = 3
    const val STRINGS = 4
    val NAMES = arrayOf("PIANO", "BRASS", "BASS", "ORGAN", "STRINGS")

    @Volatile var instrument = PIANO
    @Volatile var volume = 0.7f      // 0..1
    @Volatile var octaveShift = 0    // 0 = C3..C5
    @Volatile var reverb = 0.25f     // 0..1
    @Volatile var sustain = 0.4f     // 0..1 -> tiempo de release

    // ------------------------------------------------------------------ banco de samples
    private const val SAMPLE_RATE = 32000
    private const val FIRST = 24
    private val STEP = intArrayOf(3, 4, 4, 4, 4)
    private val COUNT = intArrayOf(29, 22, 19, 22, 22)
    private val FILE = arrayOf("piano", "brass", "bass", "organ", "strings")
    private val SLEVEL = floatArrayOf(1.0f, 1.0f, 1.0f, 0.9f, 0.9f)
    private val bank = Array(5) { arrayOfNulls<ShortArray>(COUNT[it]) }
    private val bankLoop = Array(5) { IntArray(COUNT[it]) }
    @Volatile private var readyMask = 0
    private var loading = false

    private fun loadBank(ctx: Context) {
        if (loading) return
        loading = true
        val first = instrument
        Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            val order = ArrayList<Int>()
            order.add(first)
            for (i in 0..4) if (i != first) order.add(i)
            for (inst in order) {
                try {
                    for (k in 0 until COUNT[inst]) {
                        val m = FIRST + k * STEP[inst]
                        val bytes = ctx.assets.open("samples/${FILE[inst]}_$m.pcm").use { it.readBytes() }
                        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                        bankLoop[inst][k] = bb.getInt(0)
                        bb.position(4)
                        val sb = bb.asShortBuffer()
                        val arr = ShortArray(sb.remaining())
                        sb.get(arr)
                        bank[inst][k] = arr
                    }
                    readyMask = readyMask or (1 shl inst)
                } catch (_: Exception) {
                    // sin samples para este instrumento: queda la síntesis de respaldo
                }
            }
        }, "samples").start()
    }

    // ------------------------------------------------------------------ voces
    private class Voice {
        var active = false; var id = 0; var inst = 0; var stage = 0 // 0 ataque, 1 sostén, 2 release
        var age = 0; var env = 0f; var atkInc = 0f; var relMul = 0.999f
        var n = 0; var level = 0f; var freq = 0.0
        val ph = DoubleArray(8); val inc = DoubleArray(8)
        val amp = FloatArray(8); val mul = FloatArray(8)
        var noise = 0f; var nmul = 0.99f
        var z1 = 0f; var z2 = 0f; var a = 0.1f
        // samples
        var smp: ShortArray? = null
        var pos = 0.0; var rate = 1.0; var len = 0; var loopS = -1
    }

    private val voices = Array(16) { Voice() }
    private val events = ConcurrentLinkedQueue<IntArray>()
    private var nextId = 0
    private var refs = 0
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null
    @Volatile private var sr = 48000
    private var burst = 256
    private var seed = 22222

    private val TAB = FloatArray(2049) { sin(2.0 * PI * it / 2048.0).toFloat() }
    private val ATK = floatArrayOf(0.0015f, 0.035f, 0.003f, 0.004f, 0.15f)
    private val LEVEL = floatArrayOf(0.55f, 0.5f, 0.6f, 0.4f, 0.45f)
    private val REL_SCALE = floatArrayOf(1.0f, 0.8f, 0.7f, 0.5f, 1.2f)
    private val PIANO_A = floatArrayOf(1f, .7f, .45f, .35f, .22f, .15f, .1f, .06f)
    private val ORGAN_R = doubleArrayOf(0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 8.0)
    private val ORGAN_A = floatArrayOf(.6f, 1f, .25f, .7f, .35f, .3f, .12f, .1f)
    private val BASS_A = floatArrayOf(1f, .7f, .4f, .2f, .1f)
    private val BASS_T = doubleArrayOf(2.5, 1.0, .5, .3, .2)

    fun acquire(ctx: Context) {
        synchronized(this) { refs++; if (refs == 1) start(ctx.applicationContext) }
    }

    fun release() {
        synchronized(this) { if (refs > 0) { refs--; if (refs == 0) stop() } }
    }

    fun noteOn(midi: Int): Int { val id = ++nextId; events.add(intArrayOf(1, id, midi, instrument)); return id }
    fun noteOff(id: Int) { events.add(intArrayOf(0, id, 0, 0)) }

    private fun start(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        sr = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        burst = (am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256).coerceIn(64, 1024)
        for (v in voices) { v.active = false; v.smp = null }
        events.clear()
        loadBank(ctx)
        // Sin requestAudioFocus(): no interrumpe YouTube/Spotify/WhatsApp.
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setBufferSizeInBytes(burst * 2 * 4 * 4)
            .build()
        t.setBufferSizeInFrames(burst * 2)
        t.play()
        track = t
        running = true
        thread = Thread({ loop(t) }, "synth").also { it.start() }
    }

    private fun stop() {
        running = false
        try { thread?.join(500) } catch (_: InterruptedException) {}
        track?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        track = null; thread = null
    }

    private fun gainFor(v: Float) = v * v * 2.2f

    private fun relSec(inst: Int): Float {
        val s = sustain
        return (0.03f + s * s * 2.5f) * REL_SCALE[inst]
    }

    // ------------------------------------------------------------------ reverb (Freeverb)
    private const val REV_FB = 0.86f
    private const val REV_DAMP = 0.3f

    private class Comb(size: Int) {
        val b = FloatArray(size); var i = 0; var s = 0f
        fun p(x: Float): Float {
            val o = b[i]
            s = o * (1f - REV_DAMP) + s * REV_DAMP
            b[i] = x + s * REV_FB + 1e-20f
            if (++i == b.size) i = 0
            return o
        }
    }

    private class Allpass(size: Int) {
        val b = FloatArray(size); var i = 0
        fun p(x: Float): Float {
            val o = b[i]
            b[i] = x + o * 0.5f + 1e-20f
            if (++i == b.size) i = 0
            return o - x
        }
    }

    private class Reverb(rate: Int) {
        private val sc = rate / 44100f
        private val combT = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
        private val apT = intArrayOf(556, 441, 341, 225)
        private val spread = (23 * sc).toInt()
        private val cl = Array(8) { Comb(max(8, (combT[it] * sc).toInt())) }
        private val cr = Array(8) { Comb(max(8, (combT[it] * sc).toInt() + spread)) }
        private val al = Array(4) { Allpass(max(8, (apT[it] * sc).toInt())) }
        private val ar = Array(4) { Allpass(max(8, (apT[it] * sc).toInt() + spread)) }
        var l = 0f; var r = 0f
        fun process(x: Float) {
            val inp = x * 0.015f
            var a = 0f; var b = 0f
            for (c in cl) a += c.p(inp)
            for (c in cr) b += c.p(inp)
            for (q in al) a = q.p(a)
            for (q in ar) b = q.p(b)
            l = a * 3f; r = b * 3f
        }
    }

    // ------------------------------------------------------------------ hilo de audio
    private fun loop(t: AudioTrack) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val out = FloatArray(burst * 2); val mix = FloatArray(burst)
        val rv = Reverb(sr)
        var curG = gainFor(volume); var tick = 0; var lastUr = 0; var bufFrames = burst * 2
        var polyG = 1f
        while (running) {
            var e = events.poll()
            while (e != null) { handle(e); e = events.poll() }
            java.util.Arrays.fill(mix, 0f)
            var nAct = 0
            for (v in voices) if (v.active) {
                nAct++
                if (v.smp != null) renderSample(v, mix, burst) else render(v, mix, burst)
            }
            // compensación de polifonía: más notas simultáneas -> menos ganancia por nota
            val pt = 1f / sqrt(max(1f, nAct * 0.5f))
            polyG += (pt - polyG) * 0.15f
            val step = (gainFor(volume) - curG) / burst
            val wet = reverb * 0.5f
            for (i in 0 until burst) {
                curG += step
                val d = mix[i] * curG * polyG
                rv.process(d)
                out[2 * i] = soft(d + rv.l * wet)
                out[2 * i + 1] = soft(d + rv.r * wet)
            }
            if (t.write(out, 0, burst * 2, AudioTrack.WRITE_BLOCKING) < 0) break
            if (++tick % 200 == 0) { // si hay underruns, agranda el buffer de a un burst
                val ur = t.underrunCount
                if (ur > lastUr && bufFrames < burst * 6) { bufFrames += burst; t.setBufferSizeInFrames(bufFrames) }
                lastUr = ur
            }
        }
    }

    private fun soft(x: Float): Float {
        val c = if (x > 3f) 3f else if (x < -3f) -3f else x
        return c * (27f + c * c) / (27f + 9f * c * c)
    }

    private fun handle(e: IntArray) {
        if (e[0] == 1) {
            var v: Voice? = voices.firstOrNull { !it.active }
            if (v == null) v = voices.filter { it.stage == 2 }.maxByOrNull { it.age } ?: voices.maxByOrNull { it.age }
            startVoice(v!!, e[1], e[2], e[3])
        } else {
            for (v in voices) if (v.active && v.id == e[1] && v.stage != 2) {
                v.stage = 2
                v.relMul = exp(-6.9078 / (relSec(v.inst) * sr)).toFloat()
            }
        }
    }

    private fun startVoice(v: Voice, id: Int, midi: Int, inst: Int) {
        if ((readyMask and (1 shl inst)) != 0) initSample(v, id, midi, inst) else initSynth(v, id, midi, inst)
    }

    // ------------------------------------------------------------------ voz de samples
    private fun initSample(v: Voice, id: Int, midi: Int, inst: Int) {
        val tm = if (inst == BASS) midi - 12 else midi
        val idx = ((tm - FIRST).toFloat() / STEP[inst]).roundToInt().coerceIn(0, COUNT[inst] - 1)
        val sm = FIRST + idx * STEP[inst]
        val arr = bank[inst][idx]!!
        v.active = true; v.id = id; v.inst = inst; v.stage = 0; v.age = 0; v.env = 0f
        v.smp = arr
        v.len = arr.size - 4
        v.loopS = bankLoop[inst][idx]
        v.pos = 0.0
        v.rate = 2.0.pow((tm - sm) / 12.0) * (SAMPLE_RATE.toDouble() / sr)
        v.level = SLEVEL[inst]
        v.atkInc = 1f / (0.0025f * sr)
    }

    private fun renderSample(v: Voice, mix: FloatArray, n: Int) {
        val s = v.smp
        if (s == null) { v.active = false; return }
        val len = v.len; val loopS = v.loopS; val rate = v.rate; val lvl = v.level
        val inv = 1f / 32768f
        var pos = v.pos; var env = v.env; var stage = v.stage
        for (i in 0 until n) {
            if (stage == 0) { env += v.atkInc; if (env >= 1f) { env = 1f; stage = 1 } }
            else if (stage == 2) {
                env *= v.relMul
                if (env < 0.0008f) { v.active = false; v.smp = null; return }
            }
            if (pos >= len) {
                if (loopS in 0 until len) pos -= (len - loopS).toDouble()
                else { v.active = false; v.smp = null; return }
            }
            val ip = pos.toInt()
            val f = (pos - ip).toFloat()
            val y0 = s[if (ip > 0) ip - 1 else 0] * inv
            val y1 = s[ip] * inv
            val y2 = s[ip + 1] * inv
            val y3 = s[ip + 2] * inv
            val c1 = 0.5f * (y2 - y0)
            val c2 = y0 - 2.5f * y1 + 2f * y2 - 0.5f * y3
            val c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2)
            mix[i] += (((c3 * f + c2) * f + c1) * f + y1) * env * lvl
            pos += rate
        }
        v.pos = pos; v.env = env; v.stage = stage
        v.age += n
    }

    // ------------------------------------------------------------------ síntesis de respaldo
    private fun initSynth(v: Voice, id: Int, midi: Int, inst: Int) {
        v.active = true; v.id = id; v.inst = inst; v.stage = 0; v.age = 0; v.env = 0f
        v.smp = null
        v.z1 = 0f; v.z2 = 0f; v.noise = 0f
        val f = 440.0 * 2.0.pow(((if (inst == BASS) midi - 12 else midi) - 69) / 12.0)
        v.freq = f; v.level = LEVEL[inst]
        v.atkInc = 1f / (ATK[inst] * sr)
        val nyq = sr * 0.45
        when (inst) {
            PIANO -> {
                v.n = 8
                val t0 = (5.0 * (261.6 / f).pow(0.7)).coerceIn(0.35, 6.0)
                for (k in 0 until 8) {
                    val h = k + 1
                    val fr = f * h * sqrt(1.0 + 0.0003 * h * h)
                    v.ph[k] = 0.0; v.inc[k] = fr / sr
                    v.amp[k] = if (fr < nyq) PIANO_A[k] else 0f
                    v.mul[k] = exp(-1.0 / (t0 / (1.0 + 0.8 * k) * sr)).toFloat()
                }
                v.noise = 0.12f; v.nmul = exp(-1.0 / (0.006 * sr)).toFloat()
            }
            ORGAN -> {
                v.n = 8
                for (k in 0 until 8) {
                    val fr = f * ORGAN_R[k]
                    v.ph[k] = 0.0; v.inc[k] = fr / sr
                    v.amp[k] = if (fr < nyq) ORGAN_A[k] else 0f
                    v.mul[k] = 1f
                }
                v.noise = 0.05f; v.nmul = exp(-1.0 / (0.004 * sr)).toFloat()
            }
            BASS -> {
                v.n = 5
                val b = (110.0 / f).pow(0.3).coerceIn(0.5, 1.5)
                for (k in 0 until 5) {
                    val fr = f * (k + 1)
                    v.ph[k] = 0.0; v.inc[k] = fr / sr
                    v.amp[k] = if (fr < nyq) BASS_A[k] else 0f
                    v.mul[k] = exp(-1.0 / (BASS_T[k] * b * sr)).toFloat()
                }
            }
            BRASS -> {
                v.n = 2
                val d = doubleArrayOf(0.99827, 1.00174)
                for (k in 0 until 2) { v.ph[k] = 0.25 * k; v.inc[k] = f * d[k] / sr }
            }
            else -> { // STRINGS
                v.n = 3
                val d = doubleArrayOf(0.99596, 1.0, 1.00406)
                for (k in 0 until 3) { v.ph[k] = Math.random(); v.inc[k] = f * d[k] / sr }
            }
        }
        if (inst == PIANO || inst == ORGAN || inst == BASS) {
            var s = 0f
            for (k in 0 until v.n) s += v.amp[k]
            if (s > 0f) for (k in 0 until v.n) v.amp[k] /= s
        }
    }

    private fun sine(p: Double): Float {
        val x = p * 2048.0; val i = x.toInt(); val f = (x - i).toFloat()
        return TAB[i] + (TAB[i + 1] - TAB[i]) * f
    }

    private fun blep(t: Double, dt: Double): Double {
        if (t < dt) { val x = t / dt; return x + x - x * x - 1.0 }
        if (t > 1.0 - dt) { val x = (t - 1.0) / dt; return x * x + x + x + 1.0 }
        return 0.0
    }

    private fun rnd(): Float {
        seed = seed xor (seed shl 13); seed = seed xor (seed ushr 17); seed = seed xor (seed shl 5)
        return seed * 4.6566e-10f
    }

    private fun render(v: Voice, mix: FloatArray, n: Int) {
        val additive = v.inst == PIANO || v.inst == ORGAN || v.inst == BASS
        if (!additive) {
            val fc = if (v.inst == BRASS) v.freq * (2.0 + 6.0 * min(1.0, v.age / (0.09 * sr))) else v.freq * 3.0 + 900.0
            v.a = (1.0 - exp(-2.0 * PI * min(fc, sr * 0.4) / sr)).toFloat()
        }
        for (i in 0 until n) {
            if (v.stage == 0) { v.env += v.atkInc; if (v.env >= 1f) { v.env = 1f; v.stage = 1 } }
            else if (v.stage == 2) {
                v.env *= v.relMul
                if (v.env < 0.0008f) { v.active = false; return }
            }
            var s = 0f
            if (additive) {
                for (k in 0 until v.n) {
                    val p = v.ph[k]
                    s += v.amp[k] * sine(p)
                    var q = p + v.inc[k]; if (q >= 1.0) q -= 1.0
                    v.ph[k] = q; v.amp[k] *= v.mul[k]
                }
                if (v.noise > 1e-4f) { s += v.noise * rnd(); v.noise *= v.nmul }
            } else {
                var x = 0.0
                for (k in 0 until v.n) {
                    val t = v.ph[k]; val dt = v.inc[k]
                    x += 2.0 * t - 1.0 - blep(t, dt)
                    var q = t + dt; if (q >= 1.0) q -= 1.0
                    v.ph[k] = q
                }
                v.z1 += v.a * ((x / v.n).toFloat() - v.z1)
                v.z2 += v.a * (v.z1 - v.z2)
                s = v.z2
            }
            mix[i] += s * v.env * v.level
        }
        v.age += n
        if (v.inst == PIANO || v.inst == BASS) {
            var tot = 0f
            for (k in 0 until v.n) { if (v.amp[k] < 1e-6f) v.amp[k] = 0f; tot += v.amp[k] }
            if (tot < 1e-4f) v.active = false
        }
    }
}
