package com.walo.minipiano

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Process
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Sintetizador polifónico (16 voces) sobre AudioTrack de baja latencia. Sin Audio Focus. */
object Synth {
    const val PIANO = 0
    const val BRASS = 1
    const val BASS = 2
    const val ORGAN = 3
    const val STRINGS = 4
    val NAMES = arrayOf("PIANO", "BRASS", "BASS", "ORGAN", "STRINGS")

    @Volatile var instrument = PIANO
    @Volatile var volume = 0.7f      // 0..1 -> ganancia = v^2 * 3 (con limitador suave)
    @Volatile var octaveShift = 0    // 0 = C3..C5

    private class Voice {
        var active = false; var id = 0; var inst = 0; var stage = 0 // 0 ataque, 1 sostén, 2 release
        var age = 0; var env = 0f; var atkInc = 0f; var relStep = 0f; var relFrames = 1f
        var n = 0; var level = 0f; var freq = 0.0
        val ph = DoubleArray(8); val inc = DoubleArray(8)
        val amp = FloatArray(8); val mul = FloatArray(8)
        var noise = 0f; var nmul = 0.99f
        var z1 = 0f; var z2 = 0f; var a = 0.1f
    }

    private val voices = Array(16) { Voice() }
    private val events = ConcurrentLinkedQueue<IntArray>()
    private var nextId = 0
    private var refs = 0
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null
    @Volatile private var sr = 48000
    private var burst = 256
    private var seed = 22222

    private val TAB = FloatArray(2049) { sin(2.0 * PI * it / 2048.0).toFloat() }
    private val ATK = floatArrayOf(0.0015f, 0.035f, 0.003f, 0.004f, 0.15f)
    private val REL = floatArrayOf(0.025f, 0.025f, 0.03f, 0.02f, 0.04f)
    private val LEVEL = floatArrayOf(0.55f, 0.5f, 0.6f, 0.4f, 0.45f)
    private val PIANO_A = floatArrayOf(1f, .7f, .45f, .35f, .22f, .15f, .1f, .06f)
    private val ORGAN_R = doubleArrayOf(0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 8.0)
    private val ORGAN_A = floatArrayOf(.6f, 1f, .25f, .7f, .35f, .3f, .12f, .1f)
    private val BASS_A = floatArrayOf(1f, .7f, .4f, .2f, .1f)
    private val BASS_T = doubleArrayOf(2.5, 1.0, .5, .3, .2)

    fun acquire(ctx: Context) {
        synchronized(this) { refs++; if (refs == 1) start(ctx.applicationContext) }
    }

    fun release() {
        synchronized(this) { if (refs > 0) { refs--; if (refs == 0) stop() } }
    }

    fun noteOn(midi: Int): Int { val id = ++nextId; events.add(intArrayOf(1, id, midi, instrument)); return id }
    fun noteOff(id: Int) { events.add(intArrayOf(0, id, 0, 0)) }

    private fun start(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        sr = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        burst = (am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256).coerceIn(64, 1024)
        for (v in voices) v.active = false
        events.clear()
        // Sin requestAudioFocus(): no interrumpe YouTube/Spotify/WhatsApp.
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setBufferSizeInBytes(burst * 4 * 4)
            .build()
        t.setBufferSizeInFrames(burst * 2)
        t.play()
        track = t
        running = true
        thread = Thread({ loop(t) }, "synth").also { it.start() }
    }

    private fun stop() {
        running = false
        try { thread?.join(500) } catch (_: InterruptedException) {}
        track?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        track = null; thread = null
    }

    private fun gainFor(v: Float) = v * v * 3f

    private fun loop(t: AudioTrack) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val out = FloatArray(burst); val mix = FloatArray(burst)
        var curG = gainFor(volume); var tick = 0; var lastUr = 0; var bufFrames = burst * 2
        while (running) {
            var e = events.poll()
            while (e != null) { handle(e); e = events.poll() }
            java.util.Arrays.fill(mix, 0f)
            for (v in voices) if (v.active) render(v, mix, burst)
            val step = (gainFor(volume) - curG) / burst
            for (i in 0 until burst) { curG += step; out[i] = soft(mix[i] * curG) }
            if (t.write(out, 0, burst, AudioTrack.WRITE_BLOCKING) < 0) break
            if (++tick % 200 == 0) { // si hay underruns, agranda el buffer de a un burst
                val ur = t.underrunCount
                if (ur > lastUr && bufFrames < burst * 6) { bufFrames += burst; t.setBufferSizeInFrames(bufFrames) }
                lastUr = ur
            }
        }
    }

    private fun soft(x: Float): Float {
        val c = if (x > 3f) 3f else if (x < -3f) -3f else x
        return c * (27f + c * c) / (27f + 9f * c * c)
    }

    private fun handle(e: IntArray) {
        if (e[0] == 1) {
            var v: Voice? = voices.firstOrNull { !it.active }
            if (v == null) v = voices.filter { it.stage == 2 }.maxByOrNull { it.age } ?: voices.maxByOrNull { it.age }
            init(v!!, e[1], e[2], e[3])
        } else {
            for (v in voices) if (v.active && v.id == e[1] && v.stage != 2) {
                v.stage = 2; v.relStep = maxOf(v.env, 0.001f) / v.relFrames
            }
        }
    }

    private fun init(v: Voice, id: Int, midi: Int, inst: Int) {
        v.active = true; v.id = id; v.inst = inst; v.stage = 0; v.age = 0; v.env = 0f
        v.z1 = 0f; v.z2 = 0f; v.noise = 0f
        val f = 440.0 * 2.0.pow(((if (inst == BASS) midi - 12 else midi) - 69) / 12.0)
        v.freq = f; v.level = LEVEL[inst]
        v.atkInc = 1f / (ATK[inst] * sr); v.relFrames = REL[inst] * sr
        val nyq = sr * 0.45
        when (inst) {
            PIANO -> {
                v.n = 8
                val t0 = (5.0 * (261.6 / f).pow(0.7)).coerceIn(0.35, 6.0)
                for (k in 0 until 8) {
                    val h = k + 1
                    val fr = f * h * sqrt(1.0 + 0.0003 * h * h)
                    v.ph[k] = 0.0; v.inc[k] = fr / sr
                    v.amp[k] = if (fr < nyq) PIANO_A[k] else 0f
                    v.mul[k] = exp(-1.0 / (t0 / (1.0 + 0.8 * k) * sr)).toFloat()
                }
                v.noise = 0.12f; v.nmul = exp(-1.0 / (0.006 * sr)).toFloat()
            }
            ORGAN -> {
                v.n = 8
                for (k in 0 until 8) {
                    val fr = f * ORGAN_R[k]
                    v.ph[k] = 0.0; v.inc[k] = fr / sr
                    v.amp[k] = if (fr < nyq) ORGAN_A[k] else 0f
                    v.mul[k] = 1f
                }
                v.noise = 0.05f; v.nmul = exp(-1.0 / (0.004 * sr)).toFloat()
            }
            BASS -> {
                v.n = 5
                val b = (110.0 / f).pow(0.3).coerceIn(0.5, 1.5)
                for (k in 0 until 5) {
                    val fr = f * (k + 1)
                    v.ph[k] = 0.0; v.inc[k] = fr / sr
                    v.amp[k] = if (fr < nyq) BASS_A[k] else 0f
                    v.mul[k] = exp(-1.0 / (BASS_T[k] * b * sr)).toFloat()
                }
            }
            BRASS -> {
                v.n = 2
                val d = doubleArrayOf(0.99827, 1.00174)
                for (k in 0 until 2) { v.ph[k] = 0.25 * k; v.inc[k] = f * d[k] / sr }
            }
            else -> { // STRINGS: 3 sierras desafinadas (±7 cents) = efecto coro
                v.n = 3
                val d = doubleArrayOf(0.99596, 1.0, 1.00406)
                for (k in 0 until 3) { v.ph[k] = Math.random(); v.inc[k] = f * d[k] / sr }
            }
        }
        if (inst == PIANO || inst == ORGAN || inst == BASS) {
            var s = 0f
            for (k in 0 until v.n) s += v.amp[k]
            if (s > 0f) for (k in 0 until v.n) v.amp[k] /= s
        }
    }

    private fun sine(p: Double): Float {
        val x = p * 2048.0; val i = x.toInt(); val f = (x - i).toFloat()
        return TAB[i] + (TAB[i + 1] - TAB[i]) * f
    }

    private fun blep(t: Double, dt: Double): Double {
        if (t < dt) { val x = t / dt; return x + x - x * x - 1.0 }
        if (t > 1.0 - dt) { val x = (t - 1.0) / dt; return x * x + x + x + 1.0 }
        return 0.0
    }

    private fun rnd(): Float {
        seed = seed xor (seed shl 13); seed = seed xor (seed ushr 17); seed = seed xor (seed shl 5)
        return seed * 4.6566e-10f
    }

    private fun render(v: Voice, mix: FloatArray, n: Int) {
        val additive = v.inst == PIANO || v.inst == ORGAN || v.inst == BASS
        if (!additive) {
            val fc = if (v.inst == BRASS) v.freq * (2.0 + 6.0 * min(1.0, v.age / (0.09 * sr))) else v.freq * 3.0 + 900.0
            v.a = (1.0 - exp(-2.0 * PI * min(fc, sr * 0.4) / sr)).toFloat()
        }
        for (i in 0 until n) {
            if (v.stage == 0) { v.env += v.atkInc; if (v.env >= 1f) { v.env = 1f; v.stage = 1 } }
            else if (v.stage == 2) { v.env -= v.relStep; if (v.env <= 0f) { v.active = false; return } }
            var s = 0f
            if (additive) {
                for (k in 0 until v.n) {
                    val p = v.ph[k]
                    s += v.amp[k] * sine(p)
                    var q = p + v.inc[k]; if (q >= 1.0) q -= 1.0
                    v.ph[k] = q; v.amp[k] *= v.mul[k]
                }
                if (v.noise > 1e-4f) { s += v.noise * rnd(); v.noise *= v.nmul }
            } else {
                var x = 0.0
                for (k in 0 until v.n) {
                    val t = v.ph[k]; val dt = v.inc[k]
                    x += 2.0 * t - 1.0 - blep(t, dt)
                    var q = t + dt; if (q >= 1.0) q -= 1.0
                    v.ph[k] = q
                }
                v.z1 += v.a * ((x / v.n).toFloat() - v.z1)
                v.z2 += v.a * (v.z1 - v.z2)
                s = v.z2
            }
            mix[i] += s * v.env * v.level
        }
        v.age += n
        if (v.inst == PIANO || v.inst == BASS) {
            var tot = 0f
            for (k in 0 until v.n) { if (v.amp[k] < 1e-6f) v.amp[k] = 0f; tot += v.amp[k] }
            if (tot < 1e-4f) v.active = false
        }
    }
}
